#pragma once
#include <iostream>
#include "HeaderForSeaBattle.h"
#include <conio.h>



int arraySize = 10, userChoiceMenu, choiceTable, x = 0, y = 0, ship = 0, addToX = 1, addToY = 0;
string player1, player2;