﻿#include "varibles.h"

using namespace std;

int main()
{

	cout << "1 - play with your friend\n2 - play with computer\n" << endl;
	cin >> userChoiceMenu;
	system("cls");

	if (userChoiceMenu == 1)
	{
		cout << "Input player 1 name: ";
		cin >> player1;
		cout << "\nInput player 2 name: ";
		cin >> player2;

		system("cls");
		cout << "Welcome " << player1 << " and " << player2 << "!\n\n";
		system("pause");
		system("cls");

		char** myTableVisible = new char* [arraySize];
		char** opponentTableVisible = new char* [arraySize];
		char** myTableUnVisible = new char* [arraySize];
		char** opponentTableUnVisible = new char* [arraySize];
		for (size_t i = 0; i < arraySize; i++)
		{
			myTableVisible[i] = new char[arraySize];
			opponentTableVisible[i] = new char[arraySize];
			myTableUnVisible[i] = new char[arraySize];
			opponentTableUnVisible[i] = new char[arraySize];
		}

		//початкове заповнення поля 
		for (size_t i = 0; i < arraySize; i++)
		{
			for (size_t k = 0; k < arraySize; k++)
			{
				myTableVisible[i][k] = char(247);
				opponentTableVisible[i][k] = char(247);
				myTableUnVisible[i][k] = char(247);
				opponentTableUnVisible[i][k] = char(247);
			}
		}

		cout << player1 << "'s table" << endl;

		for (size_t i = 0; i < arraySize; i++)
		{
			for (size_t k = 0; k < arraySize; k++)
			{
				cout << myTableUnVisible[i][k] << " ";
			}
			cout << endl;
		}
		cout << endl;

		cout << "1 - " << char(254) << "\n2 - " << char(254) << char(254) << "\n3 - " << char(254) << char(254) << char(254) << "\n4 - " << char(254) << char(254) << char(254) << char(254) << "\n\n";
		cin >> choiceTable;
		
		char ch = _getch();
		while(ship != 4){
			system("cls");
			cout << "now is " << ship + 1 << " one square ship" << endl;
			cout << "press enter to continue" << endl;
			printTableOne(myTableUnVisible, arraySize, 0, 0, player1);
			x = 0;
			y = 0;
			ch = 0;
			while (ch != '\r') {
				ch = _getch();
				if (ch == 'w' && y != 0)
				{
					y--;
				}
				else if (ch == 's' && y != arraySize - 1)
				{
					y++;
				}
				else if (ch == 'a' && x != 0)
				{
					x--;
				}
				else if (ch == 'd' && x != arraySize - 1)
				{
					x++;
				}
				system("cls");
				cout << "now is " << ship + 1 << " one square ship" << endl;
				cout << "press enter to continue" << endl;
				printTableOne(myTableUnVisible, arraySize, x, y, player1);
			}
			myTableUnVisible[y][x] = char(254);
		    ship++;
		}
		ship = 0;
		while (ship != 3)
		{
			system("cls");
			cout << "now is " << ship + 1 << " two square ship" << endl;
			cout << "press \"f\" to turn the ship" << endl;
			cout << "press \"c\" to turn the ship back" << endl;
			cout << "press enter to continue" << endl;
			printTableTwo(myTableUnVisible, arraySize, 0, 0, addToX, addToY, player1);
			x = 0;
			y = 0;
			ch = 0;
			while (ch != '\r')
			{
				ch = _getch();
				if (ch == 'f')
				{
					addToX = 0;
					addToY = 1;
				}
				else if(ch == 'c')
				{
					addToX = 1;
					addToY = 0;
				}
				if (ch == 'w' && y != 0)
				{
					y--;
				}
				else if (ch == 's' && y != arraySize - 2)
				{
					y++;
				}
				else if (ch == 'a' && x != 0)
				{
					x--;
				}
				else if (ch == 'd' && x != arraySize - 2)
				{
					x++;
				}
				system("cls");
				cout << "now is " << ship + 1 << " two square ship" << endl;
				cout << "press \"f\" to turn the ship" << endl;
				cout << "press \"c\" to turn the ship back" << endl;
				cout << "press enter to continue" << endl;
				printTableTwo(myTableUnVisible, arraySize, x, y, addToX, addToY, player1);
			}
			myTableUnVisible[y][x] = char(254);
			myTableUnVisible[y + addToY][x + addToX] = char(254);
			ship++;
		}


		system("cls");
		printTableFriend(myTableUnVisible, opponentTableVisible, arraySize, player1, player2);
	}
	else if (userChoiceMenu == 2) {
		cout << "coming soon" << endl;
	}


	return 7;

}
