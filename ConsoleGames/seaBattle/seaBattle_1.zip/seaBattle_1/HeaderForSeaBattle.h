#pragma once

using namespace std;

void printTableFriend(char** myTable, char** opponentTable, int arraySize, string player1, string player2) {
	cout << "\033[33m" << player1 << "                        " << player2 << endl;
	cout << "\033[35m" << "    a b c d e f g h i g         a b c d e f g h i g\n" << "\033[0m";

	for (size_t i = 0; i < arraySize; i++)
	{
		cout << "\033[35m" << i + 1 << "  " << "\033[0m";
		if (i + 1 != 10)
		{
			cout << " ";
		}
		for (size_t k = 0; k < arraySize; k++)
		{
			cout << myTable[i][k] << " ";
		}
		cout << "    ";
		cout << "\033[35m" << i + 1 << "  " << "\033[0m";
		if (i + 1 != 10)
		{
			cout << " ";
		}
		for (size_t k = 0; k < arraySize; k++)
		{
			cout << opponentTable[i][k] << " ";
		}
		cout << endl;
	}
}

void printTableOne(char** table, int arraySize, int x, int y, string player) {
	cout << player << "'s table" << endl;
	cout << "\033[35m" << "   a b c d e f g h i g\n" << "\033[0m";
	for (size_t i = 0; i < arraySize; i++)
	{
		cout << i + 1 << "  ";
		if (i + 1 != 10)
		{
			cout << " ";
		}
		for (size_t k = 0; k < arraySize; k++)
		{

			if (i == y && x == k)
			{
				cout << char(254) << " ";
				continue;
			}
			cout << table[i][k] << " ";
		}
		cout << endl;
	}
}

void printTableTwo(char** table, int arraySize, int x, int y, int addToX, int addToY, string player) {
	cout << player << "'s table" << endl;
	cout << "\033[35m" << "    a b c d e f g h i g\n" << "\033[0m";
	for (size_t i = 0; i < arraySize; i++)
	{
		cout << i + 1 << "  ";
		if (i + 1 != 10)
		{
			cout << " ";
		}
		for (size_t k = 0; k < arraySize; k++)
		{

			if (i == y && x == k)
			{
				cout << char(254) << " ";
				continue;
			}
			if (i == y + addToY && k == x + addToX)
			{
				cout << char(254) << " ";
				continue;
			}
			cout << table[i][k] << " ";
		}
		cout << endl;
	}
}